package com.example.midterm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    TextView tv_welcome, tv_coursefees, tv_courseHour, tv_totalFee, tv_totalHour;
    CheckBox caccomo, cmedical;
    ArrayList<Course> courseList = new ArrayList<>();
    ArrayList<String> courseName = new ArrayList<>();
    ArrayList<String> selectedCourse = new ArrayList<>();
    Spinner spinner;
    Button btn_add;
    RadioButton rgraduate, rngraduate;
    int limitHour = 0;
    double totFee = 0;
    int totHour = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        //initialising components
        initViews();

        //Setting Student name with welcome ;after getting from loginPage
        tv_welcome.setText("Welcome " + getIntent().getStringExtra("StudentName"));

        //Filling course data with name,fees,hours
        fillData();

        //Setting course names in spinner
        ArrayAdapter spinnerArrayAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, courseName);
        spinner.setAdapter(spinnerArrayAdapter);

        spinner.setOnItemSelectedListener(this);
        btn_add.setOnClickListener(this);
        rgraduate.setOnClickListener(this);
        rngraduate.setOnClickListener(this);
        cmedical.setOnCheckedChangeListener(this);
        caccomo.setOnCheckedChangeListener(this);
        cmedical.setOnCheckedChangeListener(this);
    }

    private void fillData() {
        courseList.add(new Course("JAVA", 1300.00, 6));
        courseList.add(new Course("Swift", 1500.00, 5));
        courseList.add(new Course("iOS", 1350.00, 5));
        courseList.add(new Course("Android", 1400.00, 7));
        courseList.add(new Course("Database", 1000.00, 4));

        for (int i = 0; i < courseList.size(); i++) {
            courseName.add(courseList.get(i).getCouserName());
        }
    }

    private void initViews() {
        tv_welcome = findViewById(R.id.tv_welcome);
        spinner = findViewById(R.id.spinner);
        tv_coursefees = findViewById(R.id.tv_coursefees);
        tv_courseHour = findViewById(R.id.tv_courseHour);
        tv_totalFee = findViewById(R.id.tv_totalFee);
        tv_totalHour = findViewById(R.id.tv_totalHour);
        btn_add = findViewById(R.id.btn_add);
        rgraduate = findViewById(R.id.rgraduate);
        rngraduate = findViewById(R.id.rngraduate);
        caccomo = findViewById(R.id.caccomo);
        cmedical = findViewById(R.id.cmedical);
    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        tv_coursefees.setText(String.valueOf(courseList.get(i).getCouserFees()));
        tv_courseHour.setText(String.valueOf(courseList.get(i).getCouserHour()));
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.btn_add:
                //check if course is already in selected list or not

                if (selectedCourse.contains(spinner.getSelectedItem())) {
                    Toast.makeText(MainActivity.this, spinner.getSelectedItem() + " is already selected", Toast.LENGTH_SHORT).show();

                } else {
                    selectedCourse.add(spinner.getSelectedItem().toString());
                    //none of radio button is selected
                    if (limitHour == 0) {
                        Toast.makeText(MainActivity.this, "Choose graduated or ungraduated option", Toast.LENGTH_SHORT).show();
                    } else {
                        //on clik of add fees and hours will be added
                        totFee = totFee + Double.parseDouble(tv_coursefees.getText().toString());
                        totHour = totHour + Integer.parseInt(tv_courseHour.getText().toString());
                        //if graduated is selected
                        if (rgraduate.isChecked() == true) {

                            // if hours greater than 21 than last added values will be subtracted
                            if (totHour > 21) {
                                totFee = totFee - Double.parseDouble(tv_coursefees.getText().toString());
                                totHour = totHour - Integer.parseInt(tv_courseHour.getText().toString());
                                Toast.makeText(MainActivity.this, "you can’t add this course", Toast.LENGTH_SHORT).show();
                            }

                        }
                        //if ungraduated is selected
                        else if (rngraduate.isChecked() == true) {
                            // if hours greater than 19 than last added values will be subtracted
                            if (totHour > 19) {
                                totFee = totFee - Double.parseDouble(tv_coursefees.getText().toString());
                                totHour = totHour - Integer.parseInt(tv_courseHour.getText().toString());
                                Toast.makeText(MainActivity.this, "you can’t add this course", Toast.LENGTH_SHORT).show();

                            }
                        }
                        tv_totalFee.setText(String.format("%.2f", totFee));
                        tv_totalHour.setText(String.valueOf(totHour));


                    }
                }


                break;
            case R.id.rgraduate:
                limitHour = 21;
                //reset to 0 or startover
                reset();
                break;
            case R.id.rngraduate:
                limitHour = 19;
                //reset to 0 or startover
                reset();
                break;
        }
    }

    private void reset() {

        selectedCourse = new ArrayList<>();
        cmedical.setChecked(false);
        caccomo.setChecked(false);
        totFee = 0;
        totHour = 0;
        tv_totalFee.setText(String.format("%.2f", totFee));
        tv_totalHour.setText(String.valueOf(totHour));
        //re-initialising arraylist (clear exisiting data)
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        switch (compoundButton.getId()) {
            case R.id.caccomo:
//checking for accomodation checkbox if checked 1000 will be added
                if (caccomo.isChecked()) {
                    totFee = totFee + 1000;
                } else {
                    totFee = totFee - 1000;
                }
                tv_totalFee.setText(String.format("%.2f", totFee));
                break;
            case R.id.cmedical:
                //checking for medical checkbox if checked 700 will be added
                if (cmedical.isChecked()) {
                    totFee = totFee + 700;

                } else {
                    totFee = totFee - 700;
                }
                tv_totalFee.setText(String.format("%.2f", totFee));
                break;
        }
    }
}
