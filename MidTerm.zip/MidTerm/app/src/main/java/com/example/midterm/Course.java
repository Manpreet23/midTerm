package com.example.midterm;

public class Course {
    private String couserName;
    private Double couserFees;
    private int couserHour;

    public Course(String couserName, Double couserFees, int couserHour) {
        this.couserName = couserName;
        this.couserFees = couserFees;
        this.couserHour = couserHour;
    }

    public String getCouserName() {
        return couserName;
    }

    public Double getCouserFees() {
        return couserFees;
    }

    public int getCouserHour() {
        return couserHour;
    }
}
