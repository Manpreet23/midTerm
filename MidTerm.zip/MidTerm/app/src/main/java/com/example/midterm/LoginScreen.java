package com.example.midterm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginScreen extends AppCompatActivity implements View.OnClickListener {
EditText et_userName,et_Password,et_StudentName;
Button btn_submit;
String username = "student1";
String password = "123456";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_login_screen);

        //initialising all components
        initViews();

        btn_submit.setOnClickListener(this);
    }

    private void initViews() {
        et_userName =findViewById(R.id.et_userName);
        et_Password =findViewById(R.id.et_Password);
        et_StudentName =findViewById(R.id.et_StudentName);
        btn_submit=findViewById(R.id.btn_submit);
    }

    @Override
    public void onClick(View view) {

        if (et_userName.getText().toString().equals("")|| et_Password.getText().toString().equals("")||et_StudentName.getText().toString().equals(""))
        {
            Toast.makeText(LoginScreen.this,"Fields must not be empty",Toast.LENGTH_LONG).show();
        }
        else if (!et_userName.getText().toString().equals(username)|| !et_Password.getText().toString().equals("123456"))
        {
            Toast.makeText(LoginScreen.this,"invalid username or password",Toast.LENGTH_LONG).show();
        }
        else
        {
            Intent home = new Intent(LoginScreen.this,MainActivity.class);
            home.putExtra("StudentName",et_StudentName.getText().toString());
            startActivity(home);
        }
    }
}